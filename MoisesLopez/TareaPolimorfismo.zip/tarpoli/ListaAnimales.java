package com.moiseslopezp.tarpoli;
import java.util.ArrayList;

public class ListaAnimales {
	private ArrayList<Animal> listanimals;
	
	public ListaAnimales(){
		listanimals = new ArrayList<Animal>();
	}
	
	public void AddAnimal(Animal _newanimal)
	{
		listanimals.add(_newanimal);
	}
	public void Listar()
	{
		System.out.println("Se mostrara los datos de los Animales existentes");
		for (Animal pmp: listanimals)
		{
			pmp.MostrarNpatas();
		}
	}
}
