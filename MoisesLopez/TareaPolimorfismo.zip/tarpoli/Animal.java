package com.moiseslopezp.tarpoli;

public class Animal {
	
	protected int Patas;
	private String Nombre;
	
	public Animal()
	{
		this.Nombre = "Desconocido";
		this.Patas = 4;
	}
	
	public Animal(int _patas, String _nombre)
	{
		this.Nombre = _nombre;
		this.Patas = _patas;
	}

	public int getPatas() {
		return Patas;
	}

	public String getNombre() {
		return Nombre;
	}
	void MostrarNpatas()
	{
		System.out.println("Este Elefante llamado "+this.getNombre()+" Tiene "+this.getPatas()+" Patas");
	}
}
