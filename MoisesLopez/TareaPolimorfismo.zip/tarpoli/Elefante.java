package com.moiseslopezp.tarpoli;

public class Elefante extends Mamifero{
	public Elefante(int _patas, String _nombre)
	{
		super(_patas, _nombre);
	}
	void MostrarNpatas()
	{
		System.out.println("Este Elefante llamado "+this.getNombre()+" Tiene "+this.getPatas()+" Patas");
	}
}
