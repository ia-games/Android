package com.moiseslopezp.tarpoli;

public class Humano extends Mamifero {
	
	public Humano(int _patas, String _nombre)
	{
		super(_patas, _nombre);
	}
	public Humano(String _nombre)
	{
		super(2, _nombre);
	}
	public Humano()
	{
		super(2, "Humano Desconocido");
	}
	void MostrarNpatas()
	{
		System.out.println("Este Humano llamado "+this.getNombre()+" Tiene "+this.getPatas()+" Patas");
	}
}
