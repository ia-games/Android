package com.moiseslopezp.tarpoli;

public class Mamifero extends Animal{
	
	public Mamifero(int _patas, String _nombre)
	{
		super(_patas, _nombre);
	}
	
	void MostrarNpatas()
	{
		System.out.println("Este Mamifero llamado "+this.getNombre()+" Tiene "+this.getPatas()+" Patas");
	}
}
