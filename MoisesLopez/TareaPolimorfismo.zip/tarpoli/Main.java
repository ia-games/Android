package com.moiseslopezp.tarpoli;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pez mipez = new Pez("Juan");
		Mamifero mimamifero = new Mamifero(3,"Jorge");
		Elefante mielefante = new Elefante(4,"Pancho");
		Humano mihumano = new Humano("Jose");
		
		ListaAnimales _animalitos = new ListaAnimales();
		_animalitos.AddAnimal(mipez);
		_animalitos.AddAnimal(mielefante);
		_animalitos.AddAnimal(mimamifero);
		_animalitos.AddAnimal(mihumano);
		
		_animalitos.Listar();
	}

}
