package com.moiseslopezp.tarpoli;

public class Pez extends Animal{
	
	public Pez(int _patas, String _nombre)
	{
		super(_patas, _nombre);
	}
	public Pez(String _nombre)
	{
		super(0, _nombre);
	}
	public Pez()
	{
		super(0, "Pez sin Nombre");
	}
	void MostrarNpatas()
	{
		System.out.println("Este Pez llamado "+this.getNombre()+" Tiene "+this.getPatas()+" Patas");
	}

}
