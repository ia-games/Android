package Examen_Empleados;

public class Repartidor extends Empleado {
	
	int Pedidos;

	public Repartidor(String nombre, String apellido, int edad, float sueldo, int pedidos) {
		super(nombre, apellido, edad, sueldo);
		this.Pedidos= pedidos;
	}

	public int getPedidos() {
		return Pedidos;
	}

	public void setPedidos(int pedidos) {
		Pedidos = pedidos;
	}
	
	public void Completarpedido()
	{
		if (Pedidos>0)
		{
			System.out.println("Se completo un pedido");
			Pedidos--;
		} else {
			System.out.println("Ya no hay mas pedidos");
		}
	}

}
