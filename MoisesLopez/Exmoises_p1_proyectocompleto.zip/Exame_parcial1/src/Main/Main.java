package Main;

import Examen_Empleados.Comercial;
import Examen_Empleados.Repartidor;

public class Main {

	public static void main(String[] args) {
		Comercial Juan = new Comercial("Juan","Perez",26,250,8,5);
		Repartidor Pedro = new Repartidor("Pedro","Ramirez",30,200,6);
		
		System.out.println("Ahora existe Un repartidor y un Comercial");
		System.out.println("Los dos tienen Nombre, Apellido, edad y sueldo");
		
		System.out.println("Datos del Repartidor -> ");
		System.out.println("Nombre: "+Juan.getNombre());
		System.out.println("Apellido: "+Juan.getApellido());
		System.out.println("Edad: "+Juan.getEdad());
		System.out.println("Sueldo: "+Juan.getSueldo());
		
		System.out.println("Datos del Comercial -> ");
		System.out.println("Nombre: "+Pedro.getNombre());
		System.out.println("Apellido: "+Pedro.getApellido());
		System.out.println("Edad: "+Pedro.getEdad());
		System.out.println("Sueldo: "+Pedro.getSueldo());
		
		System.out.println("Cada tiene tareas diferentes");
		System.out.println(Juan.getNombre()+" (Numero de clientes): "+Juan.getNoClientes());
		System.out.println(Juan.getNombre()+" (Ventas): "+Juan.getVentas());
		System.out.println(Pedro.getNombre()+" (Pedidos): "+Pedro.getPedidos());
		
		System.out.println("Comienza el trabajo (cada uno hace algo diferente)");
		for (int i=0; i<3; i++)
		{
			System.out.print(Juan.getNombre()+" -> ");
			Juan.Vender();
			System.out.print("\n"+Pedro.getNombre()+" -> ");
			Pedro.Completarpedido();
		}
		
		System.out.println("Informe despues de trabajar");
		System.out.println(Juan.getNombre()+" (Numero de clientes): "+Juan.getNoClientes());
		System.out.println(Juan.getNombre()+" (Ventas): "+Juan.getVentas());
		System.out.println(Pedro.getNombre()+" (Pedidos): "+Pedro.getPedidos());
		
		System.out.println("Los dos pueden obtener sueldo");
		System.out.println(Juan.getNombre()+" -> ");
		Juan.Obtener_sueldo();
		System.out.println(Pedro.getNombre()+" -> ");
		Pedro.Obtener_sueldo();
	}

}
