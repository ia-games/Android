package com.factorial.moiseslopezp;

public class Fraccion {

	private int divisor, dividendo;
	
	public Fraccion() {
		divisor=1;
		dividendo=1;
	}
	
	public void set(int _ds, int _dv)
	{
		divisor = _ds;
		dividendo = _dv;
	}
	
	public void get()
	{
		if (divisor==dividendo) {
			System.out.println("1");} else 
			System.out.println(divisor+"/"+dividendo);
	}
	
	public void Multiplicar(int _ds, int _dv)
	{
		divisor *= _ds;
		dividendo *= _dv;
		get();
	}
	public void Dividir(int _ds, int _dv)
	{
		divisor *= _dv;
		dividendo *= _ds;
		get();
	}
	public void Sumar(int _ds, int _dv)
	{
		divisor = (divisor*_dv)+(_ds*dividendo);
		dividendo = dividendo * _dv;
		get();
	}
	public void Resta(int _ds, int _dv)
	{
		divisor = (divisor*_dv)-(_ds*dividendo);
		dividendo = dividendo * _dv;
		get();
	}
}
