package com.factorial.moiseslopezp;

public class testfracciones {

	public static void main(String[] args) {
		System.out.println("Creamos la Fraccion 3/5");
		Fraccion mifraccion = new Fraccion(); 
		mifraccion.set(3, 5);
		mifraccion.get();
		System.out.println("Le sumamos 2/7");
		mifraccion.Sumar(2, 7);
		System.out.println("Le Restamos 1/4");
		mifraccion.Resta(1, 4);
		System.out.println("Lo Multiplicamos por 10/11");
		mifraccion.Multiplicar(10, 11);
		System.out.println("Lo Dividimos entre 2/3");
		mifraccion.Dividir(2, 3);
	}

}
