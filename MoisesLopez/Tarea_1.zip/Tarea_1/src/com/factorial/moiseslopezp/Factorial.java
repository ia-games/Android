package com.factorial.moiseslopezp;
import java.util.Scanner; 

public class Factorial {

	public static int getfactorial(int _n)
	{
		if (_n<=0) {return 1;}
		
		int _resultado = 1;
		
		for (int i=1; i<=_n; i++)
		{
			_resultado*=i;
		}
		return _resultado;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("Calcular Factorial");
		System.out.println("Escribe un numero");
		int _numero, resultado;
		_numero = in.nextInt();
		resultado=getfactorial(_numero);
		System.out.println("El factorial es "+resultado);
	}

}
