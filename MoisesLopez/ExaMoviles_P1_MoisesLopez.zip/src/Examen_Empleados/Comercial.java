package Examen_Empleados;

public class Comercial extends Empleado {
	
	private int NoClientes;
	private int Ventas;

	public Comercial(String nombre, String apellido, int edad, float sueldo, int noClientes, int ventas) {
		super(nombre,apellido,edad,sueldo);
		this.NoClientes = noClientes;
		this.Ventas = ventas;
	}

	public int getNoClientes() {
		return NoClientes;
	}

	public void setNoClientes(int noClientes) {
		NoClientes = noClientes;
	}

	public int getVentas() {
		return Ventas;
	}

	public void setVentas(int ventas) {
		Ventas = ventas;
	}
	
	public void Vender()
	{
		System.out.print("Vendiendo");
		setVentas(Ventas + 1);
	}
	
}
