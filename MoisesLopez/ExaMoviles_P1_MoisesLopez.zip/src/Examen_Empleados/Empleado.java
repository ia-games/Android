package Examen_Empleados;

public class Empleado {
	
	protected String Nombre;
	protected String Apellido;
	protected int Edad;
	protected float Sueldo;
	
	public Empleado(String nombre, String apellido, int edad, float sueldo) {
		super();
		this.Nombre = nombre;
		this.Apellido = apellido;
		this.Edad = edad;
		this.Sueldo = sueldo;
	}
	
	public void Obtener_sueldo(){
		System.out.println("Obtener Sueldo");
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public String getApellido() {
		return Apellido;
	}

	public void setApellido(String apellido) {
		Apellido = apellido;
	}

	public int getEdad() {
		return Edad;
	}

	public void setEdad(int edad) {
		Edad = edad;
	}

	public float getSueldo() {
		return Sueldo;
	}

	public void setSueldo(float sueldo) {
		Sueldo = sueldo;
	}
	
}
